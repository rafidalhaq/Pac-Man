This verison of PacMan written by Justin Watts.

To play, 
	be sure that the .dll files: AxInterop.WMPLib, and Interop.WMPLib
are present in the same folder as J34's Pac Man.exe

	be sure that the Data folder, along with the following media
files within the data folder are present: blip.wav, GhostEaten.wav
Killed.wav, LevelUp.wav, Morph.wav, and Theme.mp3

	Any of the media files in the data folder can be replaced, 
	to replace the game's sound simply move the desired sound
	to the data folder and rename the desired sound to the name
	of one of the game's included sound files. MUST BE EXACTLY
	THE SAME NAME TO WORK.



Open the game. The intro will play, to skip simply click the mouse.
Choose options to toogle on and off the following game options:

Random Super Ghost: This option will give one random ghost super
			speed on all levels after level 1.

All Super Ghosts: All ghosts have super speed

Super PacMan: You get super speed (Harder to control pacman however)

Click apply to set the changes made. Note: Changes are not saved. You
must apply desired settings each time you open the game.

	Use the arrow keys to change the direction pacman is traveling.
	Do not get touched by the ghosts, and eat all the dots to level
	up. Fruit will give you an extra life and many points depending 
	on the level. Beating a level will also give you one extra life.

